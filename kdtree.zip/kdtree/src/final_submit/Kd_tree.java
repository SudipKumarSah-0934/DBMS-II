package final_submit;

import java.io.File;
import java.util.ArrayList;
import java.util.Scanner;

import javax.swing.JFrame;
import javax.swing.JOptionPane;

public class Kd_tree {
	JFrame frame = new JFrame();
	public int K ;
	public int numberOfData ;
	public String dataArray[][] ;
	int searchingFound = -1 ;
	Scanner myObj = new Scanner(System.in);
	String searchingValue;

	public Kd_tree(){
		fetchDataFile();
		IntoArray();
	}
public void IntoArray() {
	ArrayList<String> nodeIn = new ArrayList<>() ;
	for (int j=0 ; j<K ; j++) {
		nodeIn.add(dataArray[0][j]);
	}
	

	Node root = createTreeNode(nodeIn);

	for(int i=1 ; i<numberOfData ; i++){
		nodeIn = new ArrayList<>() ;
		for(int j=0 ; j<K ; j++){
			nodeIn.add(dataArray[i][j]) ;
		}
		System.out.println(nodeIn);
		
		Node node = createTreeNode(nodeIn) ;
		insertNode(root, node, 0);
	}

	printTree(root, 0 , "root");
	System.out.println("\nEnter node value as string with commma-separated");
	searchingValue = myObj.nextLine() ;

	searchingValue = searchingValue.substring(1,searchingValue.length()-1) ;

	String str [] = searchingValue.split(",") ;
	search(root,0,"root", str, 0);
}
	public void fetchDataFile(){
		try{
			Scanner scanner = new Scanner(new File("C:\\Users\\USER\\eclipse-workspace\\kdtree\\src\\final_submit\\2D_array.txt")) ;

			K = Integer.valueOf(scanner.next()) ;
			numberOfData = Integer.valueOf(scanner.next());

			dataArray = new String[numberOfData][K] ;

			String temp ;
			String tempArray[] ;

			System.out.println(K+"d_tree with "+numberOfData+" nodes to be inserted");

			for(int i=0; i<numberOfData ; i++){
				temp = scanner.next() ;
				temp = temp.substring(1,temp.length()-1) ;
				tempArray = temp.split(",") ;
				for(int j=0; j<K ; j++){
					dataArray[i][j] = tempArray[j] ;
				}
			}
		}catch (Exception e){
			System.out.println("Exception:" + e);
		}
	}

	public Node createTreeNode(ArrayList<String> nodeIn){
		Node node = new Node() ;
		node.nodeIn = nodeIn ;

		return node ;
	}

	public void insertNode(Node parent, Node newNode, int currDim){
		if(Integer.valueOf(newNode.nodeIn.get(currDim))>=Integer.valueOf(parent.nodeIn.get(currDim))){
			if(parent.right==null){
				parent.right = newNode ;
			}
			else {
				if(currDim+1==K){
					currDim = -1 ;
				}
				insertNode(parent.right, newNode, currDim+1);
			}
		}
		else if(Integer.valueOf(newNode.nodeIn.get(currDim)) < Integer.valueOf(parent.nodeIn.get(currDim))){
			if(parent.left==null){
				parent.left = newNode ;
			}
			else {
				if(currDim+1==K){
					currDim = -1 ;
				}
				insertNode(parent.left, newNode, currDim+1);
			}
		}
	}

	public void printTree(Node node, int level, String position){
		if(node==null){
			return;
		}

		String str = null ;
		for (int i=0 ; i<K ; i++){
			if(i==0){
				str = node.nodeIn.get(i);
			}else {
				str = str + "," + node.nodeIn.get(i);
			}
		}

		if(position=="root") {
			System.out.print("\n\t\t\t\t  "+ level+"=>" + position + " node:[" + str + "]");
			System.out.println();
		}
		else if (position=="right") {
			System.out.print("\t  " + level+"=>" + position + " node:[" + str + "]\n\t\t\t\t\t\t");
		}else {
			System.out.print("\n\t\t  "+ level+"=>" + position + " node:[" + str + "]\t");
		}

		if(node.left!=null){
			printTree(node.left, level+1, "left");
		}

		if(node.right!=null){
			printTree(node.right, level+1, "right");
		}
	}

	public boolean checkMatch(Node node, String str[]){
		int matched = 0 ;
		for (int i=0 ; i<K ; i++){
			if(str[i].equals(String.valueOf(node.nodeIn.get(i)))){
				matched++ ;
			}
		}

		if(matched==K){
			return true;
		}
		return false;
	}

	public void search(Node node, int level, String position, String findNode[], int currDim){
		if(checkMatch(node, findNode)){ 
			JOptionPane.showMessageDialog(null, " : "+level+"\nPosition : "+position+"\nNode : "+searchingValue, " Success", JOptionPane.INFORMATION_MESSAGE);
			return;
		}

		if(Integer.valueOf(findNode[currDim])>=Integer.valueOf(node.nodeIn.get(currDim))){

			if(node.right==null){
				JOptionPane.showMessageDialog(null, "\nSearching Node : Not Found","Failed", JOptionPane.WARNING_MESSAGE);
			}
			else {
				if(currDim+1==K){
					currDim = -1 ;
				}
				search(node.right, level+1, "right", findNode, currDim+1);
			}
		}
		else if(Integer.valueOf(findNode[currDim]) < Integer.valueOf(node.nodeIn.get(currDim))){
			if(node.left==null){
				JOptionPane.showMessageDialog(null, "\nSearching Node : Not Found","Failed", JOptionPane.WARNING_MESSAGE);
			}
			else {
				if(currDim+1==K){
					currDim = -1 ;
				}
				search(node.left, level+1, "left", findNode, currDim+1);
			}
		}
	}

	class Node{
		Node left, right ;
		ArrayList<String> nodeIn = new ArrayList<>() ;
	}
}
