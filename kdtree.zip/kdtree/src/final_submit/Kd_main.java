package final_submit;

import javax.swing.JFrame;

public class Kd_main extends JFrame {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Kd_tree kdTree = new Kd_tree() ;	
	}
	/* (30,40), (5,25), (10,12), (70,70), (50,30), (35,45) */
	/*
	 * (10,0,100) (5,10,15) (7,7,7) (9,0,0) (4,3,2) (11,0,9) (5,6,7) (11,0,0)
	 * (9,10,11) (5,6,7) (6,5,4) (10,10,10)
	 */
}
